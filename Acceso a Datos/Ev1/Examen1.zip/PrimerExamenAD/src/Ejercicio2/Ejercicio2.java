package Ejercicio2;

public class Ejercicio2 {
}
