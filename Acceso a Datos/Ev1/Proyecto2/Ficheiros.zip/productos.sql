CREATE DATABASE IF NOT EXISTS Productos;

CREATE TABLE IF NOT EXISTS productos(

id_producto INT AUTO_INCREMENT PRIMARY KEY,
nombre_producto VARCHAR(200),
precio DOUBLE,
stock INT

);


CREATE TABLE IF NOT EXISTS pedidos_productos(

id_pedido INT NOT NULL,
id_producto INT NOT NULL,
cantidad INT NOT NULL,

PRIMARY KEY (id_pedido,id_producto),
FOREIGN KEY (id_producto) REFERENCES Productos(id_producto)

);

CREATE TABLE IF NOT EXISTS usuarios(

id_usuario INT AUTO_INCREMENT PRIMARY KEY,
nombre VARCHAR(200) NOT NULL,
email VARCHAR(200) NOT NULL,
ano_nac INT NOT NULL

);

CREATE TABLE IF NOT EXISTS pedidos(

id_pedido INT AUTO_INCREMENT NOT NULL,
id_usuario INT NOT NULL,
fecha_pedido DATE NOT NULL,

PRIMARY KEY (id_pedido),
FOREIGN KEY (id_pedido) REFERENCES pedidos_productos(id_pedido),
FOREIGN KEY (id_usuario) REFERENCES usuarios(id_usuario)

);